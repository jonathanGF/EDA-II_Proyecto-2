
package proyecto1;
import Polifase.ordenamientoPol;
public class Main {
    public static void main(String[] args) {
        
        menuPrincipal menu = new menuPrincipal();
        
        menu.setVisible(true);
         
    }
    
}
